public class test01 {

	public static void main(String[] args) {
		int s = 1;
		int res = 0;
		int sum = 1;
		for(int i = 2; i<11; i++) {
			res = s+i;
			for(int j = 0; j<i; j++) {
				sum += res;
			}
		}
		System.out.println("totalSum=" + sum);
	}
}